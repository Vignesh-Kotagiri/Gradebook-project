const students = [
    { id: 1, name: 'Virat Kohli', ticketNumber: 'A123', ratingGrade: 4.5, examGrade: 7.1, comments: 'Good work' },
    { id: 2, name: 'Rohith Sharma', ticketNumber: 'B456', ratingGrade: 3.4, examGrade: 6.2, comments: 'Needs improvement' },
    { id: 1, name: 'Jasprit Bumrah', ticketNumber: 'C789', ratingGrade: 4.0, examGrade: 6.8, comments: 'Average' },
];

function displayStudents() {
    const tableBody = document.getElementById('gradeBody');
    tableBody.innerHTML = '';
    students.forEach((student, index) => {
        const row = `<tr>
            <td>${index + 1}</td>
            <td>${student.name}</td>
            <td>${student.ticketNumber}</td>
            <td>${student.ratingGrade}</td>
            <td>${student.examGrade}</td>
            <td>${calculateFinalGrade(student)}</td>
            <td>${calculateStatus(student)}</td>
            <td>${student.comments}</td>
        </tr>`;
        tableBody.innerHTML += row;
    });
}

function calculateFinalGrade(student) {
    return (0.6 * student.examGrade + 0.4 * student.ratingGrade).toFixed(2);
}

function calculateStatus(student) {
    return (calculateFinalGrade(student) > 4) ? 'Passed' : 'Failed';
}

function filterTable() {
    const input = document.getElementById('filter').value.toLowerCase();
    const filteredStudents = students.filter(student => student.name.toLowerCase().includes(input));
    displayStudents(filteredStudents);
}

function showAll() {
    displayStudents(students);
}

function showPassed() {
    const passedStudents = students.filter(student => calculateFinalGrade(student) > 4);
    displayStudents(passedStudents);
}

function showFailed() {
    const failedStudents = students.filter(student => calculateFinalGrade(student) <= 4);
    displayStudents(failedStudents);
}

function sortByName() {
    students.sort((a, b) => a.name.localeCompare(b.name));
    displayStudents();
}

function sortByGrade() {
    students.sort((a, b) => calculateFinalGrade(b) - calculateFinalGrade(a));
    displayStudents();
}

displayStudents();